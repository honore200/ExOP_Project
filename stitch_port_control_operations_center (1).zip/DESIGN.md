---
name: Maritime Industrial Intelligence
colors:
  surface: '#f6faff'
  surface-dim: '#d2dbe4'
  surface-bright: '#f6faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ecf5fe'
  surface-container: '#e6eff8'
  surface-container-high: '#e0e9f2'
  surface-container-highest: '#dbe4ed'
  on-surface: '#141d23'
  on-surface-variant: '#44474d'
  inverse-surface: '#293138'
  inverse-on-surface: '#e9f2fb'
  outline: '#75777e'
  outline-variant: '#c5c6cd'
  surface-tint: '#515f78'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0d1c32'
  on-primary-container: '#76849f'
  inverse-primary: '#b9c7e4'
  secondary: '#006877'
  on-secondary: '#ffffff'
  secondary-container: '#75e7fe'
  on-secondary-container: '#006776'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2b1701'
  on-tertiary-container: '#9f7d5b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#b9c7e4'
  on-primary-fixed: '#0d1c32'
  on-primary-fixed-variant: '#39475f'
  secondary-fixed: '#a4eeff'
  secondary-fixed-dim: '#62d6ed'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#004e5a'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#e7bf99'
  on-tertiary-fixed: '#2b1701'
  on-tertiary-fixed-variant: '#5d4124'
  background: '#f6faff'
  on-background: '#141d23'
  surface-variant: '#dbe4ed'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-tabular:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  sidebar_width: 260px
  sidebar_collapsed: 64px
  topbar_height: 56px
  gutter: 16px
  container_padding: 24px
---

## Brand & Style

This design system is engineered for the high-stakes environment of a Port Operational Control Center. The visual style is **Industrial Modern**, prioritizing rapid data ingestion and situational awareness over decorative aesthetics. 

The brand personality is authoritative, precise, and reliable. It utilizes a structured, grid-based approach reminiscent of physical control consoles. The interface minimizes cognitive load by using a sober, neutral foundation, allowing status-based color signals to command immediate attention. Whitespace is used functionally to separate logical groupings of data rather than for artistic "breathing room."

## Colors

The palette is anchored by **Deep Navy (#0A192F)**, used for structural elements like the persistent sidebar to provide a "frame" of stability. The main workspace uses a light gray/off-white background to ensure high contrast for text and data visualizations.

**Status-Semantic Colors** are the most critical part of this system. They must be used sparingly and only to represent operational states:
- **Normal (Green):** Operations proceeding within parameters.
- **Warning (Orange):** Non-critical deviation or upcoming scheduled event.
- **Critical (Red):** Immediate attention required; operational stoppage or safety risk.
- **Information (Light Blue):** Non-urgent system notifications or tracking data.

## Typography

**Inter** is selected for its exceptional legibility at small sizes and its neutral, systematic tone. 

The system utilizes a "Data-First" typographic hierarchy. Large display sizes are reserved for critical KPI numbers. The `data-tabular` style uses tabular figures (monospaced numbers) to ensure that columns of digits align perfectly in high-density tables, preventing visual jitter during live updates. `label-caps` is used for metadata headers and secondary categorization to differentiate labels from actionable data.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model designed for ultra-wide control center monitors. 
- **Sidebar:** A persistent Deep Navy sidebar on the left contains primary navigation. It is collapsible to an icon-only view to maximize screen real estate for data tables.
- **Top Bar:** Contains breadcrumbs, global search, and high-level "Pulse" indicators showing the total number of active critical alerts.
- **Grid:** A 12-column grid is used for dashboard layouts. Spacing follows a tight 4px baseline to allow for high data density, with 16px gutters between cards.

On mobile/tablet, the sidebar becomes a temporary drawer, and data tables must transition to "Card-List" views.

## Elevation & Depth

This system avoids soft shadows and "floating" elements. Depth is communicated through **Tonal Layering** and **Low-Contrast Outlines**:
- **Level 0 (Background):** Off-white (#F8F9FA).
- **Level 1 (Cards/Panels):** Pure white surface with a 1px solid border (#DEE2E6). No shadow.
- **Level 2 (Modals/Pop-overs):** Pure white surface with a subtle 4px blur shadow, 10% opacity, and a darker border (#CED4DA) to distinguish it from the background.

Active states in navigation are indicated by a 4px left-border accent in Information Blue rather than a change in depth.

## Shapes

The design system uses a **Soft (0.25rem)** roundedness level. This subtle rounding provides a modern feel while maintaining the rigid, structural integrity required for industrial software. 
- **Buttons and Inputs:** 4px radius.
- **KPI Cards:** 4px radius.
- **Status Badges:** 2px radius (near-sharp) to emphasize their "label" nature.
- **Containers:** Large dashboard sections use 4px to remain consistent with individual components.

## Components

### High-Density Tables
Tables are the core of the CCO interface. Rows should be 32px to 40px in height. Header cells use `label-caps` typography with a light gray background (#E9ECEF). Hover states should use a subtle blue tint (#F1F8FF) to help users track rows across wide screens.

### KPI Cards
Cards consist of a `label-caps` title, a large `display-lg` value, and a small trend sparkline. Status intensity is indicated by a colored top-border (2px) on the card (e.g., a Red top-border for a KPI in a critical state).

### Status Badges
Used for vessel status or equipment health. They should use a "solid" style (white text on a status color background) for Critical/Warning and an "outline" style for Normal/Info to reduce visual noise.

### Alert Panels
A dedicated vertical panel (usually on the right) for a chronological feed of system events. Each alert entry uses a high-contrast icon corresponding to the status color and includes a timestamp in `data-tabular` format.

### Input Fields
Inputs use a white background, 1px border (#CED4DA), and 4px radius. The focus state uses a 1px primary Navy border and a subtle 2px blue glow. Labeling should always be top-aligned for vertical scanning.

### Buttons
Primary buttons use Deep Navy (#0A192F) with white text. Secondary buttons use a white background with a Navy border. Action buttons for "Acknowledge Alert" should use the specific status color associated with the alert.